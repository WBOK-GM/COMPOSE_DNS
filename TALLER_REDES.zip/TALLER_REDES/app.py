from flask import Flask, request, jsonify
from neo4j import GraphDatabase

app = Flask(__name__)


URI = "bolt://neo4j-walter:7687"  
USER = "neo4j"
PASSWORD = "supersecurepassword" 

driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))

@app.route("/peliculas", methods=["GET"])
def get_peliculas():
    # Parámetros de paginación
    page = int(request.args.get("page", 1))   # Página actual
    limit = 50                                # Límite fijo
    skip = (page - 1) * limit

    query = """
    MATCH (m:Pelicula)-[:PERTENECE_A]->(g:Genero)
    OPTIONAL MATCH (d:Persona {rol:"Director"})-[:DIRIGIO]->(m)
    OPTIONAL MATCH (a:Persona {rol:"Actor"})-[:ACTUO_EN]->(m)
    RETURN m.titulo AS titulo,
           g.nombre AS genero,
           collect(DISTINCT d.nombre) AS directores,
           collect(DISTINCT a.nombre) AS actores
    SKIP $skip LIMIT $limit
    """

    with driver.session() as session:
        result = session.run(query, skip=skip, limit=limit)
        data = [record.data() for record in result]

    return jsonify({
        "page": page,
        "limit": limit,
        "results": data
    })

if __name__ == "__main__":
    app.run(debug=True)
