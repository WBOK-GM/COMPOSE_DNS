from flask import Flask, request, jsonify
from neo4j import GraphDatabase
import random

# 🔹 Conexión a Neo4j con datos propios (no los del .env general)
NEO4J_URI = "bolt://neo4j-walter:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "supersecurepassword"

# Conectar al driver de Neo4j
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

app = Flask(__name__)

# ---------- Funciones auxiliares ----------

def get_peliculas_paginadas(page, limit=50):
    query = """
    MATCH (p:Película)
    RETURN p { .id, .titulo, .director, .anio }
    SKIP $skip
    LIMIT $limit
    """
    with driver.session() as session:
        result = session.run(query, skip=(page-1)*limit, limit=limit)
        return [record["p"] for record in result]

def get_todas_peliculas():
    query = """
    MATCH (p:Película)
    RETURN p { .id, .titulo, .director, .anio }
    """
    with driver.session() as session:
        result = session.run(query)
        return [record["p"] for record in result]

def crear_pelicula():
    new_id = random.randint(1000, 9999)
    titulo = f"Pelicula {new_id}"
    director = f"Director {random.randint(1, 100)}"
    anio = random.randint(1980, 2025)

    query = """
    CREATE (p:Película {id: $id, titulo: $titulo, director: $director, anio: $anio})
    RETURN p { .id, .titulo, .director, .anio }
    """
    with driver.session() as session:
        result = session.run(query, id=new_id, titulo=titulo, director=director, anio=anio)
        return result.single()["p"]

# ---------- Endpoints ----------

@app.route("/peliculas", methods=["GET"])
def get_peliculas():
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        return jsonify({"error": "El parámetro page debe ser un número"}), 400

    data = get_peliculas_paginadas(page)
    return jsonify({
        "page": page,
        "peliculas": data
    })

@app.route("/peliculas/all", methods=["GET"])
def get_all():
    return jsonify(get_todas_peliculas())

@app.route("/peliculas", methods=["POST"])
def create_pelicula():
    pelicula = crear_pelicula()
    return jsonify({"message": "Película creada", "pelicula": pelicula}), 201

# ---------- Main ----------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
